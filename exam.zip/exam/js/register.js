

    let form = document.getElementById('registerForm');
    let emailInput = document.getElementById('emailInp');
    let userInput = document.getElementById('userInp');
    let passwordInput = document.getElementById('passInp');

    let showErr = document.getElementById('emailShowErr');
    let showUser = document.getElementById('UserShowErr');
    let passErr = document.getElementById('passShowErr');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        if (e.submitter.id === 'regBtn') {
            let isValid = true;

            if (emailInput.value === '') {
                showErr.textContent = 'Please enter your email address';
                setTimeout(() => {
                    showErr.textContent = '';
                }, 3000);
                isValid = false;
            }
            if (userInput.value === '') {
                showUser.textContent = 'Please enter user name';
                setTimeout(() => {
                    showUser.textContent = '';
                }, 3000);
                isValid = false;
            }
            if (passwordInput.value === '') {
                passErr.textContent = 'Please enter your password';
                setTimeout(() => {
                    passErr.textContent = '';
                }, 3000);
                isValid = false;
            }

            if (isValid) {
                fetch('https://dummyjson.com/user/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: userInput.value, 
                        password: passwordInput.value,
                    })
                })
                    .then(response => {
                        if (response.status === 200) {
                            return response.json();
                        } else {
                            throw new Error('Failed to log in');
                        }
                    })
                    .then(data => {
                        console.log(data);

                        emailInput.value = '';
                        userInput.value = '';
                        passwordInput.value = '';

                        window.location.href = '../html/index.html'; 
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showErr.textContent = 'Login failed. Please try again.';
                        setTimeout(() => {
                            showErr.textContent = '';
                        }, 3000);
                    });
            }
        }
    });

    let logBtn = document.getElementById('logBtn');
    logBtn.addEventListener('click', () => {
        window.location.href = '../html/login.html';
    });


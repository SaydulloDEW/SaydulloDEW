let taskSearch = document.getElementById('taskSearch');
let allCategory = document.getElementById('allCategory');
let notFinished = document.getElementById('notFinished');
let checkbox = document.getElementById('checkbox');
let editBtn = document.getElementById('editBtn');
let delBtn = document.getElementById('delBtn');
let addTask = document.getElementById('addTask');

const renderTodos = async () => {
    const response = await fetch('https://dummyjson.com/todos');
    const data = await response.json();
    const tasksContainer = document.getElementById('tasks');
    tasksContainer.innerHTML = '';

    data.todos.forEach(todo => {
        const taskElement = createTaskElement(todo);
        tasksContainer.appendChild(taskElement);
    });

    document.querySelectorAll('.check').forEach(checkbox => {
        checkbox.addEventListener('change', (event) => {
            const todoId = event.target.getAttribute('data-id');
            const isChecked = event.target.checked;
            toggleTodoCompletion(todoId, isChecked);
        });
    });
};

const createTaskElement = (todo) => {
    const taskElement = document.createElement('div');
    taskElement.classList.add('task');
    taskElement.innerHTML = `
    <input type="checkbox" class="check" ${todo.completed ? 'checked' : ''} data-id="${todo.id}" />
    <h3 class="task-text">${todo.todo}</h3>
    <div class="buttons">
      <button class="edit-btn" data-id="${todo.id}" data-todo="${todo.todo}">Edit</button>
      <button class="del-btn" data-id="${todo.id}">Delete</button>
    </div>
  `;
    return taskElement;
};

const addNewTodo = async () => {
    const newTodoText = document.getElementById('newTodoText').value;
    await fetch('https://dummyjson.com/todos/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            todo: newTodoText,
            completed: false,
            userId: 5
        })
    });
    renderTodos();
    document.getElementById('newTodoText').value = '';
    bootstrap.Modal.getInstance(document.getElementById('addTodoModal')).hide();
};

const editTodo = async (id, newTodoText) => {
    await fetch(`https://dummyjson.com/todos/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            todo: newTodoText
        })
    });
    renderTodos();
    bootstrap.Modal.getInstance(document.getElementById('editTodoModal'));
};

const deleteTodo = async (id) => {
    await fetch(`https://dummyjson.com/todos/${id}`, {
        method: 'DELETE'
    });
    renderTodos();
};

const toggleTodoCompletion = async (id, isCompleted) => {
    await fetch(`https://dummyjson.com/todos/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            completed: isCompleted
        })
    });
    renderTodos();
};

document.addEventListener('DOMContentLoaded', () => {
    renderTodos();

    document.getElementById('taskSearch').addEventListener('input', () => {
        const searchKeyword = document.getElementById('taskSearch').value.toLowerCase();
        const tasks = document.querySelectorAll('.task');

        tasks.forEach(task => {
            const taskText = task.querySelector('.task-text').textContent.toLowerCase();
            if (taskText.includes(searchKeyword)) {
                task.style.display = 'flex';
            } else {
                task.style.display = 'none';
            }
        });
    });

    document.getElementById('categoryFilter').addEventListener('change', () => {
        const filterValue = document.getElementById('categoryFilter').value;
        const tasks = document.querySelectorAll('.task');

        tasks.forEach(task => {
            const isChecked = task.querySelector('.check').checked;
            if (filterValue === 'all' || (filterValue === 'notFinished' && !isChecked)) {
                task.style.display = 'flex';
            } else {
                task.style.display = 'none';
            }
        });
    });

    document.getElementById('tasks').addEventListener('click', async (event) => {
        if (event.target.classList.contains('edit-btn')) {
            const id = event.target.getAttribute('data-id');
            const todo = event.target.getAttribute('data-todo');
            document.getElementById('editTodoText').value = todo;
            document.getElementById('updateTodo').setAttribute('data-id', id);
            const editModal = new bootstrap.Modal(document.getElementById('editTodoModal'));
            editModal.show();
        } else if (event.target.classList.contains('del-btn')) {
            const id = event.target.getAttribute('data-id');
            const confirmDelete = confirm('Are you sure you want to delete this task?');
            if (confirmDelete) {
                await deleteTodo(id);
            }
        }
    });

    document.getElementById('addTodoForm').addEventListener('submit', (event) => {
        event.preventDefault();
        addNewTodo();
    });

    document.getElementById('editTodoForm').addEventListener('submit', async (event) => {
        event.preventDefault();
        const newTodoText = document.getElementById('editTodoText').value;
        const id = document.getElementById('updateTodo').getAttribute('data-id');
        await editTodo(id, newTodoText);
    });
});

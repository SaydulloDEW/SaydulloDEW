let taskDatas = [
    {
        id: 1,
        task: 'Doing homework',
        date: '2023-06-23',
        name: 'Sam',
    },
    {
        id: 2,
        task: 'Cleaning the house',
        date: '2023-06-24',
        name: 'John',
    }
];

let row = document.querySelector('tbody');

function renderData(data) {
    row.innerHTML = '';

    data.forEach((task, index) => {
        let template = document.querySelector('.template');
        let cloneTemp = document.importNode(template.content, true);

        cloneTemp.querySelector('.number').textContent = index + 1;
        cloneTemp.querySelector('.nameOfWork').textContent = task.task;
        cloneTemp.querySelector('.dateOfWork').textContent = task.date;
        cloneTemp.querySelector('.ownerOfWork').textContent = task.name;
        cloneTemp.querySelector('#delete').setAttribute('onclick', `deleteTask(${task.id})`);
        cloneTemp.querySelector('#edit').onclick = () => {
            document.querySelector('#editTasks').value = task.task;
            document.querySelector('#editTasks').setAttribute('edit-task-id', task.id);
            document.querySelector('#editDate').value = task.date;
            document.querySelector('#editPerson').value = task.name;
        };

        row.appendChild(cloneTemp);
    });
}

renderData(taskDatas);

function addTask() {
    let new_id = taskDatas.length > 0 ? taskDatas[taskDatas.length - 1].id + 1 : 1;

    let addNewTasks = document.getElementById('addTasks');
    let addNewDate = document.getElementById('addDate');
    let addNewPerson = document.getElementById('addPerson');

    if (!addNewTasks.value || !addNewDate.value || !addNewPerson.value) {
        alert('Please enter task');
        return;
    }

    let newTask = {
        id: new_id,
        task: addNewTasks.value,
        date: addNewDate.value,
        name: addNewPerson.value,
    };

    taskDatas.push(newTask);
    renderData(taskDatas);

    addNewTasks.value = '';
    addNewDate.value = '';
    addNewPerson.value = '';
}

function deleteTask(taskId) {
    taskDatas = taskDatas.filter(task => task.id !== taskId);
    renderData(taskDatas);
}

const saveChangesButton = document.getElementById('saveChanges');

saveChangesButton.addEventListener('click', () => {
    const selectedTaskId = document.querySelector('#editTasks').getAttribute('edit-task-id');

    taskDatas.forEach(task => {
        if (task.id === selectedTaskId) {
            task.task = document.querySelector('#editTasks').value;
            task.date = document.querySelector('#editDate').value;
            task.name = document.querySelector('#editPerson').value;
        }
    });

    renderData(taskDatas);
});
